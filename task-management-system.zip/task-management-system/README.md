# Task Management System

Единый учебный проект для практических работ 1–7 по Python и Clean Architecture.
Проект показывает путь от простых сущностей и типизации до подключаемых репозиториев,
interface adapters, CLI и REST API.

## Слои

- `todo_app/domain` содержит сущности `User`, `Project`, `Task`, value objects,
  доменные правила и интерфейс репозитория. Здесь нет SQL, Flask и сетевых вызовов.
- `todo_app/application` содержит DTO, `Result`, коды ошибок и Use Cases.
  Use Case получает зависимости через конструктор.
- `todo_app/interfaces` содержит порты, включая `NotificationPort` и
  `NotificationSender`.
- `todo_app/interface_adapters` содержит Controller, Presenter и View Model.
- `todo_app/infrastructure` содержит конкретные реализации хранения и отправки
  уведомлений: InMemory, SQLite, EmailSender и SmsSender.
- `todo_app/frameworks_drivers` содержит внешние точки запуска. В проекте есть CLI
  и необязательный Flask REST API.
- `tests` содержит unit-, adapter-, integration- и SQLite-тесты.

В корне также находятся каталоги `domain`, `application`, `interfaces` и
`infrastructure`. Это тонкие compatibility-пакеты, которые переэкспортируют
основные элементы из `todo_app` и показывают требуемую структуру слоёв.

## Структура

```text
task-management-system/
├── todo_app/
│   ├── domain/
│   │   ├── entities/              # Entity, User, Project, Task
│   │   ├── value_objects/         # Priority, Deadline
│   │   ├── services/              # TaskPriorityCalculator и сервисы
│   │   ├── repositories/          # абстракции репозиториев
│   │   └── domain_types.py        # NewType, Literal и типизированные функции
│   ├── application/
│   │   ├── dto/                   # входные и выходные DTO
│   │   ├── ports/                 # NotificationPort
│   │   └── use_cases/             # Create, Complete, Assign и другие сценарии
│   ├── interfaces/                # NotificationSender и внешние порты
│   ├── interface_adapters/        # Controller, Presenter, ViewModel
│   ├── infrastructure/
│   │   ├── repositories/          # InMemoryTaskRepository, SQLiteTaskRepository
│   │   └── notifications/         # EmailSender, SmsSender
│   ├── frameworks_drivers/
│   │   ├── cli/main.py
│   │   └── web/app.py
│   └── bootstrap.py               # сборка приложения и dependency injection
├── domain/, application/, interfaces/, infrastructure/  # compatibility-пакеты
├── cli/main.py                    # удобная точка запуска CLI
├── tests/
├── examples/intentional_type_errors.py
├── scripts/check_mypy_examples.py
├── docs/practical_report.pdf
├── pyproject.toml
└── mypy.ini
```

## Установка

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev,web]"
```

Если нужна только базовая проверка без Flask, достаточно `python -m pip install -e ".[dev]"`.

## Запуск CLI

Демонстрационный сценарий выполняет операции «создать → получить → начать →
завершить → получить»:

```bash
python -m cli.main --demo
```

Отдельные команды:

```bash
python -m cli.main --db tasks.sqlite3 create "Підготувати звіт" --description "Завершити до п'ятниці"
python -m cli.main --db tasks.sqlite3 list
python -m cli.main --db tasks.sqlite3 show TASK_UUID
python -m cli.main --db tasks.sqlite3 start TASK_UUID
python -m cli.main --db tasks.sqlite3 complete TASK_UUID
```

Ключ `--db` подключает SQLite для сохранения данных между запусками. Без него
CLI использует InMemory-репозиторий для изолированного демонстрационного запуска.

## REST API

Flask подключается только во внешнем слое. Запуск:

```bash
flask --app todo_app.frameworks_drivers.web.app:create_app run --debug
```

Маршруты:

- `POST /tasks` — создать задачу;
- `GET /tasks` — получить список;
- `GET /tasks/<id>` — получить одну задачу;
- `POST /tasks/<id>/start` — перевести в `in_progress`;
- `POST /tasks/<id>/complete` — завершить задачу.

## Тесты и mypy

```bash
python -m pytest -v
mypy todo_app
python scripts/check_mypy_examples.py
```

Последняя команда намеренно запускает файл с тремя ошибками типов и проверяет,
что mypy их обнаруживает. Эти ошибки исключены из обычной проверки проекта, поэтому
основной код остаётся типизированным.

## Как выполнены задания

1. Создан каркас проекта, простые сущности и описание слоёв.
2. Добавлен намеренно плохой `BadTaskManager`, затем выделены сервисы валидации,
   назначения и уведомлений. `NotificationSender` подключается через DI, доступны
   `EmailSender` и `SmsSender`.
3. Добавлен `domain_types.py` с `NewType`, `Literal`, типизированным `Task` и
   функциями `create_task`, `assign_task`, `complete_task`, `get_tasks_by_status`.
4. Добавлены UUID Entity, Task, Project, TaskStatus, Priority, Deadline,
   переходы `start`/`complete`, `is_overdue`, `TaskPriorityCalculator` и порт
   `TaskRepository`.
5. Реализованы DTO, `Result`, `ErrorCode`, CreateTaskUseCase,
   CompleteTaskUseCase, InMemoryTaskRepository и NotificationPort.
6. Реализованы TaskController, TaskPresenter, TaskViewModel и обработка
   `VALIDATION_ERROR`.
7. Добавлены bootstrap с DI, CLI, SQLiteTaskRepository, REST API и
   интеграционные тесты. Use Cases не зависят от конкретного хранилища.

В `docs/practical_report.pdf` находится краткий отчёт для сдачи. В `artifacts/`
сохраняются результаты проверки тестов и mypy.
