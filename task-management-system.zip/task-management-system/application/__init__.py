"""Compatibility package for the application layer."""
from todo_app.application import *
