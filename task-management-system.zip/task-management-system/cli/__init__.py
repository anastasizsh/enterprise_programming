"""CLI compatibility package."""
