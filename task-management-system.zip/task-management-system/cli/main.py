from todo_app.frameworks_drivers.cli.main import main, run_demo

if __name__ == "__main__":
    raise SystemExit(main())
