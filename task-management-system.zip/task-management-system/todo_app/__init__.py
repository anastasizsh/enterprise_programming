"""Task Management System package."""

__version__ = "1.0.0"
