"""Result object for explicit success and error flows."""

from dataclasses import dataclass
from typing import Generic, TypeVar

from .errors import ErrorCode

T = TypeVar("T")


@dataclass(frozen=True)
class Result(Generic[T]):
    success: bool
    value: T | None = None
    error_code: ErrorCode | None = None
    message: str = ""

    @classmethod
    def ok(cls, value: T, message: str = "") -> "Result[T]":
        return cls(success=True, value=value, message=message)

    @classmethod
    def fail(cls, error_code: ErrorCode, message: str) -> "Result[T]":
        return cls(success=False, error_code=error_code, message=message)
