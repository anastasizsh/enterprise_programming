"""Use-case input DTOs."""

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

from ...domain.value_objects import Deadline, Priority


@dataclass(frozen=True)
class TaskRequest:
    title: str
    description: str = ""
    project_id: UUID | None = None
    assignee_id: UUID | None = None
    priority: Priority = Priority.MEDIUM
    deadline: Deadline | datetime | None = None


@dataclass(frozen=True)
class AssignTaskRequest:
    task_id: UUID
    assignee_id: UUID
    recipient: str | None = None
