"""Use-case output DTO."""

from dataclasses import asdict, dataclass
from datetime import datetime
from enum import Enum
from typing import Any
from uuid import UUID

from ...domain.entities.task import Task


@dataclass(frozen=True)
class TaskResponse:
    task_id: UUID
    title: str
    description: str
    status: str
    assignee_id: UUID | None
    project_id: UUID | None
    priority: str
    deadline: str | None

    @classmethod
    def from_task(cls, task: Task) -> "TaskResponse":
        deadline = task.deadline.due_at.isoformat() if task.deadline else None
        return cls(
            task_id=task.id,
            title=task.title,
            description=task.description,
            status=task.status.value,
            assignee_id=task.assignee_id,
            project_id=task.project_id,
            priority=task.priority.name.lower(),
            deadline=deadline,
        )

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["task_id"] = str(self.task_id)
        data["assignee_id"] = str(self.assignee_id) if self.assignee_id else None
        data["project_id"] = str(self.project_id) if self.project_id else None
        return data
