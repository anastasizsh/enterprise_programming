"""Application port kept separate from concrete notification adapters."""

from ...interfaces.notification_sender import NotificationPort, NotificationSender

__all__ = ["NotificationPort", "NotificationSender"]
