"""Compatibility import for the repository contract."""

from ...domain.repositories.task_repository import TaskRepository

__all__ = ["TaskRepository"]
