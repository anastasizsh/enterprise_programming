"""Application service facade for notifications."""

from ...domain.services.notification_service import TaskNotificationService

__all__ = ["TaskNotificationService"]
