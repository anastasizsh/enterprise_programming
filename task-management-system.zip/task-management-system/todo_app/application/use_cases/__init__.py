from .assign_task import AssignTaskUseCase
from .complete_project import CompleteProjectUseCase
from .complete_task import CompleteTaskUseCase
from .create_task import CreateTaskUseCase
from .get_task import GetTaskUseCase
from .list_tasks import ListTasksUseCase
from .start_task import StartTaskUseCase

# Short names used in the first practical work.
CreateTask = CreateTaskUseCase
CompleteTask = CompleteTaskUseCase
AssignTask = AssignTaskUseCase

__all__ = [
    "AssignTaskUseCase",
    "AssignTask",
    "CompleteProjectUseCase",
    "CompleteTaskUseCase",
    "CompleteTask",
    "CreateTaskUseCase",
    "CreateTask",
    "GetTaskUseCase",
    "ListTasksUseCase",
    "StartTaskUseCase",
]
