"""AssignTask use case."""

from uuid import UUID

from ...domain.repositories.task_repository import TaskRepository
from ...domain.services import TaskAssignmentService, TaskNotificationService
from ..common import ErrorCode, Result
from ..dto import AssignTaskRequest, TaskResponse


class AssignTaskUseCase:
    def __init__(
        self,
        repository: TaskRepository,
        assignment_service: TaskAssignmentService | None = None,
        notification_service: TaskNotificationService | None = None,
    ) -> None:
        self._repository = repository
        self._assignment_service = assignment_service or TaskAssignmentService()
        self._notification_service = notification_service

    def execute(
        self,
        request: AssignTaskRequest | UUID,
        assignee_id: UUID | None = None,
        recipient: str | None = None,
    ) -> Result[TaskResponse]:
        if isinstance(request, UUID):
            if assignee_id is None:
                return Result.fail(ErrorCode.VALIDATION_ERROR, "assignee_id is required")
            request = AssignTaskRequest(request, assignee_id, recipient)
        task = self._repository.get(request.task_id)
        if task is None:
            return Result.fail(ErrorCode.NOT_FOUND, f"task {request.task_id} was not found")
        try:
            self._assignment_service.assign(task, request.assignee_id)
            self._repository.save(task)
        except ValueError as exc:
            return Result.fail(ErrorCode.VALIDATION_ERROR, str(exc))
        except Exception as exc:
            return Result.fail(ErrorCode.INVALID_STATE, str(exc))
        if self._notification_service and request.recipient:
            self._notification_service.notify_assignment(task, request.recipient)
        return Result.ok(TaskResponse.from_task(task), "Task assigned successfully")


AssignTask = AssignTaskUseCase
