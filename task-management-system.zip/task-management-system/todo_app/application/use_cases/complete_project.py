"""Optional higher-complexity CompleteProject use case."""

from uuid import UUID

from ...domain.entities.project import Project
from ...domain.repositories.task_repository import TaskRepository
from ..common import ErrorCode, Result
from ..dto import TaskResponse


class CompleteProjectUseCase:
    """Complete all tasks belonging to a project in one application operation."""

    def __init__(self, repository: TaskRepository) -> None:
        self._repository = repository

    def execute(self, project: Project | UUID) -> Result[list[TaskResponse]]:
        if isinstance(project, UUID):
            return Result.fail(
                ErrorCode.NOT_FOUND,
                "a Project entity is required to enumerate its task ids",
            )
        responses: list[TaskResponse] = []
        for task_id in project.task_ids:
            task = self._repository.get(task_id)
            if task is None:
                return Result.fail(ErrorCode.NOT_FOUND, f"task {task_id} was not found")
            task.complete()
            self._repository.save(task)
            responses.append(TaskResponse.from_task(task))
        return Result.ok(responses, "Project tasks completed successfully")
