"""CreateTask use case."""

from datetime import datetime

from ...domain.entities.task import Task
from ...domain.exceptions import DomainError
from ...domain.repositories.task_repository import TaskRepository
from ...domain.services.task_validator import TaskValidator
from ...domain.value_objects import Deadline
from ..common import ErrorCode, Result
from ..dto import TaskRequest, TaskResponse


class CreateTaskUseCase:
    def __init__(self, repository: TaskRepository, validator: TaskValidator | None = None) -> None:
        self._repository = repository
        self._validator = validator or TaskValidator()

    def execute(
        self,
        request: TaskRequest | str | None,
        description: str = "",
    ) -> Result[TaskResponse]:
        if request is None:
            return Result.fail(ErrorCode.VALIDATION_ERROR, "task title is required")
        if isinstance(request, str):
            request = TaskRequest(title=request, description=description)
        try:
            title = self._validator.validate_title(request.title)
            clean_description = self._validator.validate_description(request.description)
            deadline = request.deadline
            if isinstance(deadline, datetime):
                deadline = Deadline(deadline)
            task = Task(
                title=title,
                description=clean_description,
                project_id=request.project_id,
                assignee_id=request.assignee_id,
                priority=request.priority,
                deadline=deadline,
            )
            self._repository.save(task)
        except (DomainError, ValueError, TypeError) as exc:
            return Result.fail(ErrorCode.VALIDATION_ERROR, str(exc))
        return Result.ok(TaskResponse.from_task(task), "Task created successfully")


# Short name retained for the initial use-case outline.
CreateTask = CreateTaskUseCase
