"""GetTask use case."""

from uuid import UUID

from ...domain.repositories.task_repository import TaskRepository
from ..common import ErrorCode, Result
from ..dto import TaskResponse


class GetTaskUseCase:
    def __init__(self, repository: TaskRepository) -> None:
        self._repository = repository

    def execute(self, task_id: UUID) -> Result[TaskResponse]:
        task = self._repository.get(task_id)
        if task is None:
            return Result.fail(ErrorCode.NOT_FOUND, f"task {task_id} was not found")
        return Result.ok(TaskResponse.from_task(task))
