"""ListTask use case."""

from ...domain.repositories.task_repository import TaskRepository
from ..common import Result
from ..dto import TaskResponse


class ListTasksUseCase:
    def __init__(self, repository: TaskRepository) -> None:
        self._repository = repository

    def execute(self) -> Result[list[TaskResponse]]:
        return Result.ok([TaskResponse.from_task(task) for task in self._repository.list_all()])
