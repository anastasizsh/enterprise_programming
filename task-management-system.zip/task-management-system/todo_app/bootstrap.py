from dataclasses import dataclass

from .application.use_cases import (
    AssignTaskUseCase,
    CompleteProjectUseCase,
    CompleteTaskUseCase,
    CreateTaskUseCase,
    GetTaskUseCase,
    ListTasksUseCase,
    StartTaskUseCase,
)
from .domain.repositories import TaskRepository
from .domain.services import TaskNotificationService
from .infrastructure.notifications import EmailSender
from .infrastructure.repositories import InMemoryTaskRepository
from .interface_adapters import TaskController, TaskPresenter
from .interfaces.notification_sender import NotificationSender


@dataclass
class Application:
    repository: TaskRepository
    create_task: CreateTaskUseCase
    complete_task: CompleteTaskUseCase
    start_task: StartTaskUseCase
    assign_task: AssignTaskUseCase
    get_task: GetTaskUseCase
    list_tasks: ListTasksUseCase
    complete_project: CompleteProjectUseCase
    controller: TaskController
    presenter: TaskPresenter
    notification_sender: NotificationSender


def create_application(
    repository: TaskRepository | None = None,
    notification_sender: NotificationSender | None = None,
) -> Application:
    concrete_repository = repository or InMemoryTaskRepository()
    sender = notification_sender or EmailSender()
    presenter = TaskPresenter()
    create_task = CreateTaskUseCase(concrete_repository)
    complete_task = CompleteTaskUseCase(concrete_repository)
    start_task = StartTaskUseCase(concrete_repository)
    notification_service = TaskNotificationService(sender)
    assign_task = AssignTaskUseCase(concrete_repository, notification_service=notification_service)
    get_task = GetTaskUseCase(concrete_repository)
    list_tasks = ListTasksUseCase(concrete_repository)
    complete_project = CompleteProjectUseCase(concrete_repository)
    controller = TaskController(create_task, presenter, complete_task, start_task)
    return Application(
        repository=concrete_repository,
        create_task=create_task,
        complete_task=complete_task,
        start_task=start_task,
        assign_task=assign_task,
        get_task=get_task,
        list_tasks=list_tasks,
        complete_project=complete_project,
        controller=controller,
        presenter=presenter,
        notification_sender=sender,
    )
