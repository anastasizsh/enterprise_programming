"""Small typed model used in the type-system exercise.

The rich domain entity lives in ``todo_app.domain.entities.task``. This module is
kept deliberately small so that NewType and Literal can be demonstrated without
mixing those concerns with persistence or framework code.
"""

from dataclasses import dataclass, replace
from typing import Literal, NewType, Sequence
from uuid import UUID

UserId = NewType("UserId", UUID)
TaskId = NewType("TaskId", UUID)
ProjectId = NewType("ProjectId", UUID)
TaskStatus = Literal["new", "in_progress", "done"]


@dataclass(frozen=True)
class Task:
    """Typed task record used by the practical work on annotations."""

    id: TaskId
    title: str
    status: TaskStatus = "new"
    assignee_id: UserId | None = None


def create_task(task_id: TaskId, title: str) -> Task:
    """Create a typed task in the ``new`` state."""

    if not title.strip():
        raise ValueError("title must not be empty")
    return Task(id=task_id, title=title.strip())


def assign_task(task: Task, assignee_id: UserId) -> Task:
    """Return a copy of a task assigned to a user."""

    return replace(task, assignee_id=assignee_id)


def complete_task(task: Task) -> Task:
    """Return a copy of a task in the ``done`` state."""

    return replace(task, status="done")


def get_tasks_by_status(tasks: Sequence[Task], status: TaskStatus) -> list[Task]:
    """Filter typed tasks by their Literal status."""

    return [task for task in tasks if task.status == status]
