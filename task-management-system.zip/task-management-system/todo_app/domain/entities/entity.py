"""Base entity with a UUID identity."""

from dataclasses import dataclass, field
from uuid import UUID, uuid4


@dataclass(kw_only=True)
class Entity:
    """Every domain entity receives a UUID when it is created."""

    id: UUID = field(default_factory=uuid4)
