"""Project entity."""

from dataclasses import dataclass, field
from uuid import UUID

from ..exceptions import ValidationError
from .entity import Entity


@dataclass(kw_only=True)
class Project(Entity):
    name: str = ""
    description: str = ""
    task_ids: set[UUID] = field(default_factory=set)

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValidationError("project name must not be empty")

    def add_task(self, task_id: UUID) -> None:
        self.task_ids.add(task_id)

    def remove_task(self, task_id: UUID) -> None:
        self.task_ids.discard(task_id)
