"""Task entity and its state transitions."""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from uuid import UUID

from ..exceptions import InvalidTaskState, ValidationError
from ..value_objects import Deadline, Priority
from .entity import Entity


class TaskStatus(str, Enum):
    NEW = "new"
    IN_PROGRESS = "in_progress"
    DONE = "done"


@dataclass(kw_only=True)
class Task(Entity):
    title: str = ""
    description: str = ""
    status: TaskStatus = TaskStatus.NEW
    assignee_id: UUID | None = None
    project_id: UUID | None = None
    priority: Priority = Priority.MEDIUM
    deadline: Deadline | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        if not self.title.strip():
            raise ValidationError("task title is required")
        if not isinstance(self.status, TaskStatus):
            self.status = TaskStatus(self.status)
        if not isinstance(self.priority, Priority):
            self.priority = Priority(int(self.priority))

    def start(self) -> None:
        """Move a new task into progress."""

        if self.status is TaskStatus.DONE:
            raise InvalidTaskState("a completed task cannot be started")
        if self.status is TaskStatus.NEW:
            self.status = TaskStatus.IN_PROGRESS

    def complete(self) -> None:
        """Complete a new or in-progress task."""

        if self.status is TaskStatus.DONE:
            return
        if self.status not in (TaskStatus.NEW, TaskStatus.IN_PROGRESS):
            raise InvalidTaskState("task cannot be completed from its current state")
        self.status = TaskStatus.DONE

    def assign_to(self, user_id: UUID) -> None:
        if self.status is TaskStatus.DONE:
            raise InvalidTaskState("a completed task cannot be reassigned")
        self.assignee_id = user_id

    def is_overdue(self, now: datetime | None = None) -> bool:
        if self.status is TaskStatus.DONE or self.deadline is None:
            return False
        return self.deadline.is_overdue(now)
