"""User entity."""

from dataclasses import dataclass

from ..exceptions import ValidationError
from .entity import Entity


@dataclass(kw_only=True)
class User(Entity):
    name: str = ""
    email: str = ""

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValidationError("user name must not be empty")
