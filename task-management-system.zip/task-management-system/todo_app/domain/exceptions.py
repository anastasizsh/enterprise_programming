"""Domain exceptions."""


class DomainError(Exception):
    """Base exception for invalid domain operations."""


class ValidationError(DomainError):
    """Raised when an entity does not satisfy domain invariants."""


class InvalidTaskState(DomainError):
    """Raised when a task transition is not allowed."""
