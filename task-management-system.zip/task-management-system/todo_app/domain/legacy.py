"""The intentionally poor design from practical work 2.

This class is kept as a learning example. It mixes validation, entity creation,
persistence, notification, and presentation in one object, which violates SRP.
Production code uses TaskValidator, TaskAssignmentService,
TaskNotificationService, repositories, and presenters separately.
"""

from uuid import UUID

from .entities.task import Task
from .repositories.task_repository import TaskRepository
from ..interfaces.notification_sender import NotificationSender


class BadTaskManager:
    """Deliberately violates the Single Responsibility Principle."""

    def __init__(self, repository: TaskRepository, sender: NotificationSender) -> None:
        self.repository = repository
        self.sender = sender

    def create_assign_and_format(self, title: str, assignee: UUID, recipient: str) -> dict[str, str]:
        # Validation, persistence, notification, and presentation are all mixed here.
        if not title.strip():
            raise ValueError("title is required")
        task = Task(title=title.strip())
        task.assign_to(assignee)
        self.repository.save(task)
        self.sender.send(recipient, "Task assigned", task.title)
        return {"id": str(task.id), "title": task.title, "status": task.status.value}
