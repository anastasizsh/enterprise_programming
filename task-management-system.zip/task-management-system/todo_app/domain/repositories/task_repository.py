from typing import Protocol
from uuid import UUID

from ..entities.task import Task


class TaskRepository(Protocol):
    def save(self, task: Task) -> Task:
        ...

    def get(self, task_id: UUID) -> Task | None:
        ...

    def list_all(self) -> list[Task]:
        ...

    def delete(self, task_id: UUID) -> bool:
        ...
