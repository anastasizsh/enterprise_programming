"""Application-facing notification orchestration."""

from uuid import UUID

from ...interfaces.notification_sender import NotificationSender
from ..entities.task import Task


class TaskNotificationService:
    """Send assignment notifications through an injected sender."""

    def __init__(self, sender: NotificationSender) -> None:
        self._sender = sender

    def notify_assignment(self, task: Task, recipient: str) -> None:
        self._sender.send(
            recipient=recipient,
            subject=f"Task assigned: {task.title}",
            message=f"Task {task.id} was assigned to you.",
        )
