"""Assignment business service."""

from uuid import UUID

from ..entities.task import Task


class TaskAssignmentService:
    def assign(self, task: Task, assignee_id: UUID) -> Task:
        task.assign_to(assignee_id)
        return task
