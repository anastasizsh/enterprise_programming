"""Priority scoring service."""

from datetime import datetime, timedelta, timezone

from ..entities.task import Task, TaskStatus


class TaskPriorityCalculator:
    """Calculate a sortable score without changing the task itself."""

    def calculate(self, task: Task, now: datetime | None = None) -> int:
        if task.status is TaskStatus.DONE:
            return 0
        score = int(task.priority) * 10
        if task.is_overdue(now):
            score += 100
        elif task.deadline is not None:
            current = now or datetime.now(timezone.utc)
            due = task.deadline.due_at
            if due.tzinfo is None:
                due = due.replace(tzinfo=timezone.utc)
            if due - current <= timedelta(days=2):
                score += 20
        return score
