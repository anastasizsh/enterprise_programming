"""Validation responsibility extracted from the deliberately bad legacy class."""

from ..exceptions import ValidationError


class TaskValidator:
    def validate_title(self, title: str) -> str:
        if not isinstance(title, str):
            raise ValidationError("task title must be a string")
        normalized = title.strip()
        if not normalized:
            raise ValidationError("task title is required")
        return normalized

    def validate_description(self, description: str) -> str:
        if not isinstance(description, str):
            raise ValidationError("task description must be a string")
        return description.strip()
