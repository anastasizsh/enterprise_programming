"""Deadline value object."""

from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass(frozen=True)
class Deadline:
    due_at: datetime

    def is_overdue(self, now: datetime | None = None) -> bool:
        current = now or datetime.now(timezone.utc)
        due = self.due_at
        if due.tzinfo is None:
            due = due.replace(tzinfo=timezone.utc)
        if current.tzinfo is None:
            current = current.replace(tzinfo=timezone.utc)
        return due < current
