"""CLI driver for the Task Management System."""

import argparse
from typing import Sequence
from uuid import UUID

from ...bootstrap import Application, create_application
from ...infrastructure.repositories import SQLiteTaskRepository
from ...interface_adapters.view_models import ErrorViewModel, TaskViewModel


def _print_view_model(model: TaskViewModel | ErrorViewModel) -> None:
    if isinstance(model, ErrorViewModel):
        print(f"ERROR [{model.error_code}]: {model.message}")
        return
    print(f"ID: {model.id}")
    print(f"Title: {model.title}")
    print(f"Status: {model.status}")
    print(model.message)


def run_demo(application: Application) -> None:
    print("=== Task Management System ===")
    print("Create task:")
    created = application.controller.create_task(
        "Підготувати звіт", "Завершити звіт до п'ятниці"
    )
    _print_view_model(created)
    if isinstance(created, ErrorViewModel):
        return
    task_id = UUID(created.id)
    print("\nGet task:")
    found = application.get_task.execute(task_id)
    print(found.value.to_dict() if found.value else found.message)
    print("\nStart task:")
    started = application.start_task.execute(task_id)
    print(started.value.to_dict() if started.value else started.message)
    print("\nComplete task:")
    completed = application.complete_task.execute(task_id)
    print(completed.value.to_dict() if completed.value else completed.message)
    print("\nVerify stored status:")
    verified = application.get_task.execute(task_id)
    print(verified.value.to_dict() if verified.value else verified.message)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Task Management System")
    parser.add_argument("--demo", action="store_true", help="run the full scenario")
    parser.add_argument(
        "--db",
        help="SQLite database path for persistence between CLI invocations",
    )
    subparsers = parser.add_subparsers(dest="command")

    create = subparsers.add_parser("create", help="create a task")
    create.add_argument("title")
    create.add_argument("--description", default="")

    subparsers.add_parser("list", help="list all tasks")
    show = subparsers.add_parser("show", help="show one task")
    show.add_argument("task_id")
    start = subparsers.add_parser("start", help="start a task")
    start.add_argument("task_id")
    complete = subparsers.add_parser("complete", help="complete a task")
    complete.add_argument("task_id")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    repository = SQLiteTaskRepository(args.db) if args.db else None
    application = create_application(repository=repository)
    if args.demo or args.command is None:
        run_demo(application)
        return 0
    if args.command == "create":
        _print_view_model(application.controller.create_task(args.title, args.description))
        return 0
    try:
        task_id = UUID(args.task_id)
    except ValueError:
        print("ERROR [VALIDATION_ERROR]: task_id must be a UUID")
        return 2
    if args.command == "list":
        list_result = application.list_tasks.execute()
        for task in list_result.value or []:
            print(task.to_dict())
    elif args.command == "show":
        show_result = application.get_task.execute(task_id)
        print(show_result.value.to_dict() if show_result.value else show_result.message)
    elif args.command == "start":
        start_result = application.start_task.execute(task_id)
        print(start_result.value.to_dict() if start_result.value else start_result.message)
    elif args.command == "complete":
        complete_result = application.complete_task.execute(task_id)
        print(complete_result.value.to_dict() if complete_result.value else complete_result.message)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
