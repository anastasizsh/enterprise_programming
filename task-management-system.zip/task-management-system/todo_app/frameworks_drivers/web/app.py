"""Optional REST API driver.

Flask is intentionally imported inside the factory so the domain and application
layers remain usable without a web framework installed.
"""

from typing import Any
from uuid import UUID

from ...bootstrap import Application, create_application
from ...application.common import ErrorCode


def create_app(application: Application | None = None) -> Any:
    try:
        from flask import Flask, jsonify, request
    except ImportError as exc: 
        raise RuntimeError("Install the 'web' extra to run the Flask API") from exc

    app = Flask(__name__)
    app.json.ensure_ascii = False
    components = application or create_application()

    @app.post("/tasks")
    def create_task() -> Any:
        payload = request.get_json(silent=True) or {}
        result = components.create_task.execute(
            payload.get("title", ""), payload.get("description", "")
        )
        status_code = 201 if result.success else 400
        if result.success and result.value:
            return jsonify(result.value.to_dict()), status_code
        return jsonify({"error_code": result.error_code.value if result.error_code else "INTERNAL_ERROR", "message": result.message}), status_code

    @app.get("/tasks")
    def list_tasks() -> Any:
        result = components.list_tasks.execute()
        return jsonify([task.to_dict() for task in result.value or []])

    @app.get("/tasks/<task_id>")
    def get_task(task_id: str) -> Any:
        try:
            parsed_id = UUID(task_id)
        except ValueError:
            return jsonify({"error_code": ErrorCode.VALIDATION_ERROR.value, "message": "task_id must be a UUID"}), 400
        result = components.get_task.execute(parsed_id)
        if result.success and result.value:
            return jsonify(result.value.to_dict())
        return jsonify({"error_code": result.error_code.value if result.error_code else "INTERNAL_ERROR", "message": result.message}), 404

    @app.post("/tasks/<task_id>/start")
    def start_task(task_id: str) -> Any:
        try:
            parsed_id = UUID(task_id)
        except ValueError:
            return jsonify({"error_code": ErrorCode.VALIDATION_ERROR.value, "message": "task_id must be a UUID"}), 400
        result = components.start_task.execute(parsed_id)
        if result.success and result.value:
            return jsonify(result.value.to_dict())
        return jsonify({"error_code": result.error_code.value if result.error_code else "INTERNAL_ERROR", "message": result.message}), 400

    @app.post("/tasks/<task_id>/complete")
    def complete_task(task_id: str) -> Any:
        try:
            parsed_id = UUID(task_id)
        except ValueError:
            return jsonify({"error_code": ErrorCode.VALIDATION_ERROR.value, "message": "task_id must be a UUID"}), 400
        result = components.complete_task.execute(parsed_id)
        if result.success and result.value:
            return jsonify(result.value.to_dict())
        return jsonify({"error_code": result.error_code.value if result.error_code else "INTERNAL_ERROR", "message": result.message}), 400

    return app
