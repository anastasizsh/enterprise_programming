"""Concrete adapters for persistence and notifications."""
