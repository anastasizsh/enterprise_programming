"""Safe email sender adapter for the exercise.

The adapter records outgoing messages instead of opening a network connection. A
real SMTP implementation can replace this class without changing use cases.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class SentEmail:
    recipient: str
    subject: str
    message: str


class EmailSender:
    def __init__(self, from_address: str = "tasks@example.com") -> None:
        self.from_address = from_address
        self.sent_messages: list[SentEmail] = []

    def send(self, recipient: str, subject: str, message: str) -> None:
        self.sent_messages.append(SentEmail(recipient, subject, message))
