"""Safe SMS sender adapter for the exercise."""

from dataclasses import dataclass


@dataclass(frozen=True)
class SentSms:
    recipient: str
    subject: str
    message: str


class SmsSender:
    def __init__(self) -> None:
        self.sent_messages: list[SentSms] = []

    def send(self, recipient: str, subject: str, message: str) -> None:
        self.sent_messages.append(SentSms(recipient, subject, message))
