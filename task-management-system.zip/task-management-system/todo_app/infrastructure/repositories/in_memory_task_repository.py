from uuid import UUID

from ...domain.entities.task import Task


class InMemoryTaskRepository:
    def __init__(self) -> None:
        self.tasks: dict[UUID, Task] = {}

    def save(self, task: Task) -> Task:
        self.tasks[task.id] = task
        return task

    def get(self, task_id: UUID) -> Task | None:
        return self.tasks.get(task_id)

    def list_all(self) -> list[Task]:
        return list(self.tasks.values())

    def delete(self, task_id: UUID) -> bool:
        return self.tasks.pop(task_id, None) is not None
