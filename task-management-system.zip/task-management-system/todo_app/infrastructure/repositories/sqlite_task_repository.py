"""SQLite repository implementing the same TaskRepository contract."""

import sqlite3
from datetime import datetime
from pathlib import Path
from uuid import UUID

from ...domain.entities.task import Task, TaskStatus
from ...domain.value_objects import Deadline, Priority


class SQLiteTaskRepository:
    def __init__(self, database_path: str | Path = "tasks.sqlite3") -> None:
        self._connection = sqlite3.connect(str(database_path))
        self._connection.row_factory = sqlite3.Row
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                status TEXT NOT NULL,
                assignee_id TEXT,
                project_id TEXT,
                priority INTEGER NOT NULL,
                deadline TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        self._connection.commit()

    def save(self, task: Task) -> Task:
        self._connection.execute(
            """
            INSERT OR REPLACE INTO tasks
            (id, title, description, status, assignee_id, project_id, priority, deadline, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(task.id),
                task.title,
                task.description,
                task.status.value,
                str(task.assignee_id) if task.assignee_id else None,
                str(task.project_id) if task.project_id else None,
                int(task.priority),
                task.deadline.due_at.isoformat() if task.deadline else None,
                task.created_at.isoformat(),
            ),
        )
        self._connection.commit()
        return task

    def get(self, task_id: UUID) -> Task | None:
        row = self._connection.execute("SELECT * FROM tasks WHERE id = ?", (str(task_id),)).fetchone()
        return self._from_row(row) if row else None

    def list_all(self) -> list[Task]:
        rows = self._connection.execute("SELECT * FROM tasks ORDER BY created_at").fetchall()
        return [self._from_row(row) for row in rows]

    def delete(self, task_id: UUID) -> bool:
        cursor = self._connection.execute("DELETE FROM tasks WHERE id = ?", (str(task_id),))
        self._connection.commit()
        return cursor.rowcount > 0

    def close(self) -> None:
        self._connection.close()

    @staticmethod
    def _from_row(row: sqlite3.Row) -> Task:
        deadline = Deadline(datetime.fromisoformat(row["deadline"])) if row["deadline"] else None
        return Task(
            id=UUID(row["id"]),
            title=row["title"],
            description=row["description"],
            status=TaskStatus(row["status"]),
            assignee_id=UUID(row["assignee_id"]) if row["assignee_id"] else None,
            project_id=UUID(row["project_id"]) if row["project_id"] else None,
            priority=Priority(row["priority"]),
            deadline=deadline,
            created_at=datetime.fromisoformat(row["created_at"]),
        )
