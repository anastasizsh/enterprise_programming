"""Thin controller for task input."""

from typing import Any

from ...application.common import ErrorCode
from ...application.dto import TaskRequest
from ...application.use_cases.create_task import CreateTaskUseCase
from ...application.use_cases.complete_task import CompleteTaskUseCase
from ...application.use_cases.start_task import StartTaskUseCase
from ..presenters import TaskPresenter


class TaskController:
    def __init__(
        self,
        create_task_use_case: CreateTaskUseCase,
        presenter: TaskPresenter,
        complete_task_use_case: CompleteTaskUseCase | None = None,
        start_task_use_case: StartTaskUseCase | None = None,
    ) -> None:
        self._create_task_use_case = create_task_use_case
        self._presenter = presenter
        self._complete_task_use_case = complete_task_use_case
        self._start_task_use_case = start_task_use_case

    def create_task(self, title: str | None, description: str | None = "") -> Any:
        if title is None or not title.strip():
            return self._presenter.present_error(
                "title is required", ErrorCode.VALIDATION_ERROR
            )
        request = TaskRequest(title=title, description=description or "")
        result = self._create_task_use_case.execute(request)
        if result.success and result.value is not None:
            return self._presenter.present_success(result.value, result.message)
        return self._presenter.present_error(
            result.message, result.error_code or ErrorCode.INTERNAL_ERROR
        )

    def complete_task(self, task_id: object) -> Any:
        if self._complete_task_use_case is None:
            return self._presenter.present_error("complete use case is not configured", ErrorCode.INTERNAL_ERROR)
        result = self._complete_task_use_case.execute(task_id)  # type: ignore[arg-type]
        if result.success and result.value is not None:
            return self._presenter.present_success(result.value, result.message)
        return self._presenter.present_error(
            result.message, result.error_code or ErrorCode.INTERNAL_ERROR
        )

    def start_task(self, task_id: object) -> Any:
        if self._start_task_use_case is None:
            return self._presenter.present_error("start use case is not configured", ErrorCode.INTERNAL_ERROR)
        result = self._start_task_use_case.execute(task_id)  # type: ignore[arg-type]
        if result.success and result.value is not None:
            return self._presenter.present_success(result.value, result.message)
        return self._presenter.present_error(
            result.message, result.error_code or ErrorCode.INTERNAL_ERROR
        )
