"""Presenter converting application DTOs to interface data."""

from ..view_models import ErrorViewModel, TaskViewModel
from ...application.common import ErrorCode
from ...application.dto import TaskResponse


class TaskPresenter:
    def present_success(self, task_response: TaskResponse, message: str = "") -> TaskViewModel:
        return TaskViewModel(
            id=str(task_response.task_id),
            title=task_response.title,
            status=task_response.status,
            message=message or "Task created successfully",
        )

    def present_error(
        self,
        message: str,
        error_code: ErrorCode | str = ErrorCode.VALIDATION_ERROR,
    ) -> ErrorViewModel:
        code = error_code.value if isinstance(error_code, ErrorCode) else str(error_code)
        return ErrorViewModel(success=False, error_code=code, message=message)
