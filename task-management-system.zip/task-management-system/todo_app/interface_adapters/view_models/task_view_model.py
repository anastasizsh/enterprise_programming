"""View models for external interfaces."""

from dataclasses import dataclass


@dataclass(frozen=True)
class TaskViewModel:
    id: str
    title: str
    status: str
    message: str


@dataclass(frozen=True)
class ErrorViewModel:
    success: bool
    error_code: str
    message: str
