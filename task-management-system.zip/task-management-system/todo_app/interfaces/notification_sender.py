"""Ports for notifications and their DI-friendly sender abstraction."""

from typing import Protocol


class NotificationPort(Protocol):
    def send(self, recipient: str, subject: str, message: str) -> None:
        ...


class NotificationSender(NotificationPort, Protocol):
    """Name used by the SRP and dependency-injection practical work."""
