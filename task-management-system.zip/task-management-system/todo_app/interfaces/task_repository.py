"""Compatibility location for the repository port."""

from ..domain.repositories.task_repository import TaskRepository

__all__ = ["TaskRepository"]
